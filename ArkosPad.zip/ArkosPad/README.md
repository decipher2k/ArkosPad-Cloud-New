# ArkosLib

ArkosLib is a simple yet powerfull information management tool.<br>
It has got a topics tree in which you can create hirarchical entries.<br>
<br>
Features:<br>
-Hirarchical topics<br>
-File attachments<br>
-HTML support<br>
-Export to Freemind mindmap (.mm)
<br><br>
<b>Changelog</b><br>
v2.1<br>
-fixed webclipper<br>
-fixed mindmap export<br><br>
v2.2<br>
-removed webclipper<br>
-removed dynamic DLL loading<br>
<br>
v2.3<br>
-added "Save" menu entry
