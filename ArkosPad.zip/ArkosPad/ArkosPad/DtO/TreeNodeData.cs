﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RicherTextBoxDemo.DtO
{
    public class XmlNodeData
    {
        public string ID = "";
        public bool focus = false;
        public int weight = 0;
    }
}
