
import { NgModule } from '@angular/core';

import { jqxTreeComponent } from './angular_jqxtree';

@NgModule({
  imports: [
  
  ],
  declarations: [jqxTreeComponent],
  exports: [jqxTreeComponent]
})
export class jqxTreeModule { }

